package service.impl;

import model.dto.EmployeeDTO;
import model.entity.Employee;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EmployeeService {
    private static final String SELECT_EMPLOYEE_ID = "select * from nhan_vien where id= ?";
    private static final String UPDATE_EMPLOYEE_SQL = "update nhan_vien set ho_ten=?,ngay_sinh=?,so_cmnd=?,luong=?,so_dien_thoai=?,ma_vi_tri=? where ma_nhan_vien=?";
    private static final String INSERT_EMPLOYEE_SQL = "insert into nhan_vien(ho_ten,ngay_sinh,so_cmnd,luong,so_dien_thoai,ma_vi_tri) values(?,?,?,?,?,?)";
    private static final String DELETE = "DELETE FROM nhan_vien WHERE ma_nhan_vien= ?";
    private static final String SORT_BY_NAME = "select * from nhan_vien order by ho_ten";
    private static final String SELECT_ALL_EMPLOYEEDTO = "select nv.ma_nhan_vien, nv.ho_ten,nv.ngay_sinh,nv.so_cmnd,nv.luong,nv.so_dien_thoai, vt.ten_vi_tri from nhan_Vien as nv join vi_tri as vt on nv.ma_vi_tri=vt.ma_vi_tri;";
    private static final String FindName = "select * from nhan_vien where ho_ten like '%?%'";
    private static  final String SORT_DTO="select nv.ho_ten,nv.ngay_sinh,nv.so_cmnd,nv.luong,nv.so_dien_thoai, vt.ten_vi_tri from nhan_Vien as nv join vi_tri as vt on nv.ma_vi_tri=vt.ma_vi_tri order by nv.ho_ten";
    private static final String FindNameDTO="select nv.ho_ten,nv.ngay_sinh,nv.so_cmnd,nv.luong,nv.so_dien_thoai, vt.ten_vi_tri from nhan_Vien as nv join vi_tri as vt on nv.ma_vi_tri=vt.ma_vi_tri where nv.ho_ten like '%?%'";


    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }


    public List<EmployeeDTO> getAll() {
        return selectDTO(SELECT_ALL_EMPLOYEEDTO);
    }

    public void save(Employee employee) {
        try (PreparedStatement preparedStatement = ConnectDB.getConnection().prepareStatement(employee.getId() > 0 ? UPDATE_EMPLOYEE_SQL : INSERT_EMPLOYEE_SQL)) {
            preparedStatement.setString(1, employee.getName());
            preparedStatement.setString(2, employee.getDob());
            preparedStatement.setString(3, employee.getIdCard());
            preparedStatement.setDouble(4, employee.getSalary());
            preparedStatement.setString(5, employee.getPhoneNumber());
            preparedStatement.setInt(6, employee.getPositionid());
            if (employee.getId() > 0) preparedStatement.setInt(7, employee.getId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }


    public void delete(int id) {
        try (PreparedStatement preparedStatement = ConnectDB.getConnection().prepareStatement(DELETE)) {
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Employee get(int id) {
        try(PreparedStatement preparedStatement= ConnectDB.getConnection().prepareStatement(SELECT_EMPLOYEE_ID)) {
            preparedStatement.setInt(1, id);
            ResultSet resultSet= preparedStatement.executeQuery();
            while (resultSet.next()){
                return getEmployee(resultSet);
            }
        }
        catch (SQLException e){
            e.printStackTrace();
        }

        return null;
    }


    public Employee getEmployee(ResultSet resultSet)throws SQLException{
        int id= resultSet.getInt(1);
        String name= resultSet.getString(2);
        String dob= resultSet.getString(3);
        String idCard= resultSet.getString(4);
        double salary= resultSet.getDouble(5);
        String phoneNumber= resultSet.getString(6);
        int positionid= resultSet.getInt(7);
        return new Employee(id,name,dob,idCard,salary,phoneNumber,positionid);
    }


    public List<EmployeeDTO> search(String find) {
        if(find=="") return selectDTO(SELECT_ALL_EMPLOYEEDTO);
        else{
            FindNameDTO.replace("?",find);
            return selectDTO(FindNameDTO);
        }
    }

    public List<EmployeeDTO> selectDTO(String sql) {
        Connection connection = ConnectDB.getConnection();
        List<EmployeeDTO> employees = new ArrayList<>();

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                EmployeeDTO employee = new EmployeeDTO();
                employee.setId(resultSet.getInt("ma_nhan_vien"));
                employee.setName(resultSet.getString("ho_ten"));
                employee.setDob(resultSet.getString("ngay_sinh"));
                employee.setIdCard(resultSet.getString("so_cmnd"));
                employee.setSalary(resultSet.getDouble("luong"));
                employee.setPhoneNumber(resultSet.getString("so_dien_thoai"));
                employee.setPosition(resultSet.getString("ten_vi_tri"));
                employees.add(employee);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return employees;
    }

}
